## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(GPH)

## -----------------------------------------------------------------------------
my_data <- rnorm(100, mean = 5, sd = 2)
model1 <- c(4, 1.5)
model2 <- c(5.5, 2.5)
models <- list(model1, model2)
result <- bayesian_model_selection(my_data, models)

## -----------------------------------------------------------------------------
X <- matrix(c(1, 2, 1, 1, 0, 2, 1, 1, 1), ncol = 3)
y <- c(3, 2, 1)
w <- weight_space_view(X, y)
print(w)

## -----------------------------------------------------------------------------
x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 6, 8, 10)
linear_covariance(x,y)

## -----------------------------------------------------------------------------
set.seed(123)
n <- 50
X <- runif(n)
y <- 2*X + rnorm(n)
alpha <- 0.01
sigma_squared <- 1
beta <- seq(-5, 5, length.out = 100)

plot_posterior_linear_covariance(X, y, alpha, beta, sigma_squared)

## -----------------------------------------------------------------------------
shinySquaredExp()

